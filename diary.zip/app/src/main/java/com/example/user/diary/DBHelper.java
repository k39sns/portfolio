package com.example.user.diary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by JungHyun on 2018-07-15.
 */

public class DBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 3;

    public DBHelper(Context context) {
        super(context, "memodb", null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String memoSQL = "create table tb_memo (_id integer primary key autoincrement, title text, content text)";
        db.execSQL(memoSQL);

        //db.execSQL("INSERT INTO tb_memo(title, content) VALUES(?, ?)", new String[]{title, content});
        String title, content, date;
        for(int i=1; i<=20; i++){
            title = i + "번째 메모";
            content = i + "번째 메모입니다.";
            db.execSQL("insert into tb_memo (title, content,date) values (?,?)", new String[]{title, content});
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(newVersion == DATABASE_VERSION){
            db.execSQL("drop table tb_memo");
            onCreate(db);
        }
    }
}
