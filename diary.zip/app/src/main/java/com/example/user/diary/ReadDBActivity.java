package com.example.user.diary;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ReadDBActivity extends AppCompatActivity implements View.OnClickListener{
    EditText titleView, contentView;
    Button addSave;
    int itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_read_db);
        setTitle("메모장 상세화면");

        titleView = (EditText)findViewById(R.id.add_title);
        contentView = (EditText)findViewById(R.id.add_content);
        addSave = (Button)findViewById(R.id.save_btn);
        addSave.setOnClickListener(this);

        //Intent 읽어오기
        Intent intent = getIntent();
        itemId = intent.getIntExtra("id", 0);

        //DB에서 데이터 읽어오기
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor rs = db.rawQuery("SELECT title, content FROM tb_memo WHERE _id=?", new String[]{Integer.toString(itemId)});
        while(rs.moveToNext()){
            titleView.setText(rs.getString(0));
            contentView.setText(rs.getString(1));
        }
        db.close();
    }

    @Override
    public void onClick(View v) {

        String title = titleView.getText().toString();
        String content = contentView.getText().toString();

        //화면에 입력된 내용을 DB에 저장하기
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase db = helper.getWritableDatabase();

        if (itemId == 0) {
            //DB에 새로 추가하는 경우
            db.execSQL("INSERT INTO tb_memo(title, content) VALUES(?, ?)", new String[]{title, content});
            Toast.makeText(getApplicationContext(), "메모가 추가됨", Toast.LENGTH_SHORT).show();
        } else {
            //DB에 update 하는 경우
            db.execSQL("UPDATE tb_memo SET title=?, content=? WHERE _id=?", new String[]{title, content, Integer.toString(itemId)});
            Toast.makeText(getApplicationContext(), "메모가 수정됨", Toast.LENGTH_SHORT).show();
        }
        db.close();

        //액티비티 종료
        finish();

    }
}
