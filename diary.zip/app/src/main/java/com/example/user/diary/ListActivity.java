package com.example.user.diary;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity implements View.OnClickListener{
    RecyclerView recyclerView;
    Button addBtn;

    ArrayList<MemoVO> datas; //데이터
    MemoAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        setTitle("메모장 목록");

        recyclerView =  findViewById(R.id.main_list);
        recyclerView.setHasFixedSize(true);

        //LayoutManager 설정 : 종류 - LinearLayoutManager, GridLayoutManager, StaggeredGridLayoutManager
        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        //LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        //layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        //StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        addBtn = findViewById(R.id.btnAdd);
        addBtn.setOnClickListener(this);

        datas = new ArrayList<>();
        getAllMemos(); //DB에서 데이터 읽어오기

        //Adapter에 출력 view, data를 설정한 뒤 ListView와 연결
        mAdapter = new MemoAdapter(this, R.layout.custom_item, datas);
        recyclerView.setAdapter(mAdapter);

        //ItemDecoration 설정 : DividerItemDecoration or 사용자정의 ItemDecoration 사용
        int offset = 5;
        recyclerView.addItemDecoration(new MemoItemDecoration(offset));
        //RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        //recyclerView.addItemDecoration(itemDecoration);
    }

    private void getAllMemos() {
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor rs = db.rawQuery("select _id,title,content from tb_memo order by _id", null);

        while(rs.moveToNext()){
            MemoVO vo = new MemoVO();

            vo.setId(rs.getInt(0));
            vo.setTitle(rs.getString(1));
            vo.setContent(rs.getString(2));

            datas.add(vo);
        }
        db.close();
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(getApplicationContext(), ReadDBActivity.class);
        intent.putExtra("id", 0);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        datas.clear();
        getAllMemos();
        mAdapter.notifyDataSetChanged();
    }

    private class MemoItemDecoration extends RecyclerView.ItemDecoration {
        private int offset;

        public MemoItemDecoration(int offset) {
            this.offset = offset;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            GridLayoutManager.LayoutParams layoutParams = (GridLayoutManager.LayoutParams) view.getLayoutParams();

            //모든 방향의 여백을 동일하게 지정
            if(layoutParams.getSpanIndex() % 2 == 0) { //왼쪽 아이템 : 오른쪽 여백을 1/2만큼 지정
                outRect.top = offset;
                outRect.left = offset;
                outRect.right = offset/2;
            }else{ //오른쪽 아이템 : 왼쪽 여백을 1/2만큼 지정
                outRect.top = offset;
                outRect.left = offset/2;
                outRect.right = offset;
            }

/*
*            super.getItemOffsets(outRect, view, parent, state);
            int index = parent.getChildAdapterPosition(view)+1;
            if(index%5 == 0){
                outRect.set(0, 0,0, offset*5); //left, top, right, bottom
            }else{
                outRect.set(0, 0, 0, 0);
            }
*/
            ViewCompat.setElevation(view, 20.0f);
        }
        @Override
        public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
            super.onDrawOver(c, parent, state);
        }
    }
}
