package com.example.user.diary;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 *    Created by user on 2018-10-16.
        */

public class MemoHolder  extends RecyclerView.ViewHolder {
    public CardView cardView;
    public ImageView typeImage;
    public TextView titleView;
    public TextView contentView;
    public TextView dateView;

    public MemoHolder(View root) {
        super(root);
        cardView = root.findViewById(R.id.cardview);
        typeImage = (ImageView)root.findViewById(R.id.type_image);
        titleView = (TextView) root.findViewById(R.id.custom_item_title);
        contentView = (TextView) root.findViewById(R.id.custom_item_content);
        dateView = (TextView)root.findViewById(R.id.date);
    }
}