package com.example.user.diary;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by user on 2018-10-16.
 */

public class MemoAdapter extends RecyclerView.Adapter<MemoHolder>{
    Context context;
    int resId;
    ArrayList<MemoVO> datas;
    private int cardPosition = 0;
    private int lastPosition = -1;

    public MemoAdapter(Context context, int resId, ArrayList<MemoVO> objects) {
        this.context = context;
        this.resId = resId;
        this.datas = objects;
    }

    @Override
    // 필수로 Generate 되어야 하는 메소드 1 : 새로운 뷰 생성
    public MemoHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(resId, parent, false);
        final MemoHolder holder = new MemoHolder(view);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cardPosition = holder.getAdapterPosition();
                if(cardPosition != RecyclerView.NO_POSITION){
                    int itemId = datas.get(cardPosition).getId();
                    Intent intent = new Intent(context, ReadDBActivity.class);
                    intent.putExtra("id", itemId);
                    context.startActivity(intent);
                } else{
                    Toast.makeText(context, "cardview.click : 존재하지 않는 아이템", Toast.LENGTH_SHORT).show();
                }
            }
        });

        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cardPosition = holder.getAdapterPosition();
                if(cardPosition != RecyclerView.NO_POSITION) {
                    int itemId = datas.get(cardPosition).getId();

                    DBHelper helper = new DBHelper(context);
                    SQLiteDatabase db = helper.getWritableDatabase();

                    db.execSQL("DELETE FROM tb_memo WHERE _id=?", new String[]{Integer.toString(itemId)});
                    db.close();
                    removeItemView(cardPosition);
                    Toast.makeText(context, "메모가 삭제됨", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(context, "cardview.longclick : 존재하지 않는 아이템", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });

        //return new MemoHolder(view);
        return holder;
    }

    @Override
    // 필수로 Generate 되어야 하는 메소드 2 : ListView의 getView 부분을 담당하는 메소드
    public void onBindViewHolder(MemoHolder holder, int position) {
        CardView cardView = holder.cardView;
        ImageView typeImage = holder.typeImage;
        TextView titleView = holder.titleView;
        TextView contentView = holder.contentView;
        TextView dateView = holder.dateView;

        MemoVO vo = datas.get(position); //항목 데이터 획득


        //view에 데이터 설정
        titleView.setText(vo.getTitle());
        contentView.setText(vo.getContent());
        dateView.setText((CharSequence) vo.getDate());
        setAnimation(holder.cardView, position);
    }

    private void setAnimation(CardView cardView, int position) {
        if (position > lastPosition) { //새로 보여지는 뷰
            Animation animation = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left);
            cardView.startAnimation(animation);
            lastPosition = position;
        } else{ //기존에 있던 뷰
            Animation animation = AnimationUtils.loadAnimation(context, android.R.anim.fade_in);
            cardView.startAnimation(animation);
        }
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    private void removeItemView(int position) {
        datas.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, datas.size()); // 지워진 만큼 다시 채워넣기.
    }
}
