package com.example.user.diary;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public static final String PREFS_NAME = "MyPrefs01";
    EditText value;
    Button loginBtn, settingBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        value = (EditText)findViewById(R.id.editName);
        loginBtn = (Button)findViewById(R.id.loginBtn);
        settingBtn = (Button)findViewById(R.id.settingBtn);
        loginBtn.setOnClickListener(this);
        settingBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == loginBtn){
            SharedPreferences sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String pref_name = sharedPref.getString("name", "");

            if(value.getText().toString().equals("")){
                Toast.makeText(this, "이름이 입력되지 않았습니다.", Toast.LENGTH_SHORT).show();
            }
            else {
                if(pref_name.equals("")){
                    //공유프레퍼런스 name을 등록함.
                    SharedPreferences.Editor editor = sharedPref.edit();
                    pref_name = value.getText().toString();
                    editor.putString("name", pref_name);
                    editor.commit();
                    Toast.makeText(this, "이름을 등록하였습니다.", Toast.LENGTH_SHORT).show();
                }

                //로그인 체크
                if (value.getText().toString().equals(pref_name)){
                    settingBtn.setEnabled(true);
                    Toast.makeText(this, "로그인 성공", Toast.LENGTH_SHORT).show();
                }else{
                    settingBtn.setEnabled(false);
                    Toast.makeText(this, "로그인 실패", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else if(v == settingBtn){
            Intent intent = new Intent(this, ListActivity.class);
            startActivity(intent);
        }
    }
}

