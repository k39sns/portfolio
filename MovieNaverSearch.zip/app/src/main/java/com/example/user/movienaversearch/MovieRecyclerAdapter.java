package com.example.user.movienaversearch;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class MovieRecyclerAdapter extends RecyclerView.Adapter<ItemHolder> {
    public Context context;
    MovieItems movieItems;
    CardView cardView;
    ImageView list_img;
    TextView txt_title,txt_pubDate,txt_director,txt_actor;

    public MovieRecyclerAdapter(Context context, MovieItems movieItems) {
        this.context = context;
        this.movieItems = movieItems;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view  = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.main_list_item,viewGroup,false);
        ItemHolder holder = new ItemHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemHolder itemHolder, int i) {
        cardView = itemHolder.cardView;
        list_img = itemHolder.list_img;
        txt_title = itemHolder.txt_title;
        txt_pubDate = itemHolder.txt_pubDate;
        txt_director = itemHolder.txt_director;
        txt_actor = itemHolder.txt_actor;
        if(!movieItems.getItems().get(i).getImage().isEmpty()){
            Glide.with(context)
                    .load(movieItems.getItems().get(i).getImage())
                    .into(list_img);
        }
        txt_title.setText(Html.fromHtml(movieItems.getItems().get(i).getTitle()));
        txt_pubDate.setText("("+movieItems.getItems().get(i).getPubDate()+")");
        txt_director.setText(movieItems.getItems().get(i).getDirector());
        txt_actor.setText(movieItems.getItems().get(i).getActor());
    }

    @Override
    public int getItemCount() {
        return movieItems.getItems().size();
    }
}
