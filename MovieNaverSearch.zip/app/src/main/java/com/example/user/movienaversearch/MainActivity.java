package com.example.user.movienaversearch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    EditText keyword;
    Button btn;
    RadioGroup rGroup;
    RecyclerView recyclerView;


    MovieItems movieitems;
    MovieRecyclerAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        keyword = findViewById(R.id.keyword);
        btn = findViewById(R.id.btn);
        rGroup = findViewById(R.id.rGroup);
        recyclerView = findViewById(R.id.main_list);

        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String genre = null;
                String key = keyword.getText().toString();
                switch (rGroup.getCheckedRadioButtonId()) {
                    case R.id.r1:
                        genre = "1";
                        break;
                    case R.id.r2:
                        genre = "4";
                        break;
                    case R.id.r3:
                        genre = "11";
                        break;
                    case R.id.r4:
                        genre = "15";
                        break;
                    case R.id.r5:
                        genre = "19";
                        break;
                    default:
                        genre = "1";
                        break;
                }

                if (!genre.isEmpty()) {
                    getMovieList(key, genre);
                }
            }

            private void getMovieList(String key, String genre) {
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("https://openapi.naver.com/v1/search/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                NaverApiService apiService = retrofit.create(NaverApiService.class);
                Call<MovieItems> call = apiService.getSearchItems(key, "20", "1", genre);
                ;
                call.enqueue(new Callback<MovieItems>() {
                    @Override
                    public void onResponse(Call<MovieItems> call, Response<MovieItems> response) {
                        if (response.isSuccessful()) {
                            movieitems = response.body();
                            if (!movieitems.getItems().isEmpty()) {
                                //어댑터 설정
                                adapter = new MovieRecyclerAdapter(MainActivity.this, movieitems);
                                recyclerView.setAdapter(adapter);
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<MovieItems> call, Throwable t) {
                        call.cancel();
                    }
                });
            }
        });
    }
}