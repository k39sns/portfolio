package com.example.user.movienaversearch;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface NaverApiService {
    @Headers({"X-Naver-Client-Id: C3DlGIyF4TlVYu81q1zJ", "X-Naver-Client-Secret: Z7jQQ00QdB"})
    @GET("movie.json")
    Call<MovieItems> getSearchItems(
            @Query(value = "query") String query,
            @Query(value = "display") String display,
            @Query(value = "start") String start,
            @Query(value = "genre") String genre
    );

//    @GET("movie.json")
//    Call<MovieItems> getSearchItemsAll(
//            @Query(value = "query") String query,
//            @Query(value = "display") String display,
//            @Query(value = "start") String start
//    );

}
