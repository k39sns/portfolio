package com.example.user.movienaversearch;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ItemHolder extends RecyclerView.ViewHolder {
    CardView cardView;
    ImageView list_img;
    TextView txt_title;
    TextView txt_pubDate;
    TextView txt_director;
    TextView txt_actor;
    public ItemHolder(@NonNull View itemView) {
        super(itemView);
        cardView = itemView.findViewById(R.id.cardView);
        list_img=itemView.findViewById(R.id.list_img);
        txt_title=itemView.findViewById(R.id.txt_title);
        txt_pubDate= itemView.findViewById(R.id.txt_pubDate);
        txt_director=itemView.findViewById(R.id.txt_director);
        txt_actor=itemView.findViewById(R.id.txt_actor);
    }
}
