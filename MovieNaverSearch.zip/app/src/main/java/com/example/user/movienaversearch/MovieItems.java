package com.example.user.movienaversearch;

import java.util.List;

public class MovieItems {

    /**
     * lastBuildDate : Mon, 19 Nov 2018 10:37:21 +0900
     * total : 34
     * start : 1
     * display : 20
     * items : [{"title":"달려라! T<b>학교<\/b> 농구부","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=172102","image":"","subtitle":"走れ！T校バスケット部","pubDate":"2018","director":"후루사와 켄|","actor":"시손 쥰|사노 하야토|하야미 아카리|토즈카 준키|","userRating":"0.00"},{"title":"<b>학교<\/b>가기 싫은 날","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=168868","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1688/168868_P01_161620.jpg","subtitle":"The Day I Hate to Go to School","pubDate":"2017","director":"김수정|","actor":"","userRating":"9.00"},{"title":"디캘브 초등<b>학교<\/b>","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=160179","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1601/160179_P01_113840.jpg","subtitle":"DeKalb Elementary","pubDate":"2016","director":"리드 반 딕|","actor":"","userRating":"0.00"},{"title":"와와의 <b>학교<\/b> 가는 날","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=54304","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0543/54304_P17_151011.jpg","subtitle":"Walking to school ","pubDate":"2015","director":"펑천|","actor":"딩지아리|아나무랑|조희문|","userRating":"9.14"},{"title":"후아유 - <b>학교<\/b> 2015","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=136960","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1369/136960_P00_111343.png","subtitle":"","pubDate":"2015","director":"백상훈|","actor":"김소현|남주혁|육성재|이필모|김희정|이초희|이다윗|조수향|","userRating":"8.69"},{"title":"JSA 남북공동초등<b>학교<\/b>","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=137291","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1372/137291_P01_162201.jpg","subtitle":"","pubDate":"2015","director":"한명구|","actor":"김지은|김예리|남동하|김미영|","userRating":"7.07"},{"title":"말하지 못한 비밀","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=113376","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1133/113376_P01_105849.jpg","subtitle":"Black Idols","pubDate":"2015","director":"송동윤|","actor":"지수|신재승|우주원|이혁|김승진|이시우|아리|","userRating":"5.50"},{"title":"의문의 사립<b>학교<\/b>","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=136562","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1365/136562_P00_174541.jpg","subtitle":"The Substitute","pubDate":"2015","director":"나단 휴즈|","actor":"데이빗 뱀버|아베 하루카|","userRating":"0.00"},{"title":"우리 <b>학교<\/b>에는 괴담이 있다","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=131429","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1314/131429_P01_165318.jpg","subtitle":"","pubDate":"2014","director":"고종원|","actor":"채주희|정하영|황연재|조아현|","userRating":"10.00"},{"title":"<b>학교<\/b> 앞 해변","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=133645","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1336/133645_P00_104904.png","subtitle":"Beach in front of Univ.","pubDate":"2014","director":"김민재|","actor":"","userRating":"10.00"},{"title":"우리들의 <b>학교<\/b>","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=150173","image":"","subtitle":"Pricey ability","pubDate":"2014","director":"임철훈|","actor":"김희상|이영상|","userRating":"0.00"},{"title":"<b>학교<\/b> 2013","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=98161","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0981/98161_P02_115608.jpg","subtitle":"","pubDate":"2012","director":"이민홍|이응복|","actor":"장나라|최다니엘|이종석|박세영|효영|김우빈|","userRating":"9.61"},{"title":"극장판 사립 바보 레어 고교","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=98915","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0989/98915_P01_105410.jpg","subtitle":"Bakaleya High School","pubDate":"2012","director":"쿠보타 타카시|","actor":"모리모토 신타로|마츠무라 호쿠토|쿄모토 타이가|시마자키 하루카|오오바 미나|루이스 제시|코우치 유고|","userRating":"6.56"},{"title":"<b>학교<\/b> 가는 길","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=101525","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/1015/101525_P01_164742.jpg","subtitle":"","pubDate":"2012","director":"신동헌|","actor":"","userRating":"10.00"},{"title":"마지스카 <b>학교<\/b> 3","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=96825","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0968/96825_P01_112019.jpg","subtitle":"マジすか&amp;#23398;園 3","pubDate":"2012","director":"","actor":"AKB48|SKE48|","userRating":"6.00"},{"title":"우리들은 세계를 바꿀 수 없다","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=83414","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0834/83414_P01_112345.jpg","subtitle":"We Can't Change the World. But, We Wanna Build a School in Cambodia.","pubDate":"2011","director":"후카사쿠 켄타|","actor":"무카이 오사무|마츠자카 토리|에모토 타스쿠|쿠보타 마사타카|무라카와 에리|쿠로카와 메이|","userRating":"0.00"},{"title":"꽝포아니야요, 남북 공동초등<b>학교<\/b>","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=81431","image":"","subtitle":"","pubDate":"2011","director":"구명철|","actor":"","userRating":"0.00"},{"title":"기숙<b>학교<\/b>: 금지된 일탈","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=81938","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0819/81938_P15_111347.jpg","subtitle":"Tanner Hall","pubDate":"2009","director":"프란체스카 그레고리니|타티아나 본 푸스텐버그|","actor":"루니 마라|조지아 킹|","userRating":"9.33"},{"title":"우리 <b>학교<\/b> 대표","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=54782","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0547/54782_P02_161729.png","subtitle":"A School Rep","pubDate":"2008","director":"박상준|","actor":"서우|서장원|김정영|","userRating":"6.63"},{"title":"<b>학교<\/b> 가는 길","link":"https://movie.naver.com/movie/bi/mi/basic.nhn?code=44652","image":"https://ssl.pstatic.net/imgmovie/mdi/mit110/0446/D4652-01.jpg","subtitle":"Buda As Sharm Foru Rikht","pubDate":"2007","director":"하나 마흐말바프|","actor":"니키바크 노루즈|아브도라리 후세이나리|압바스 알리조메|","userRating":"9.17"}]
     */

    private String lastBuildDate;
    private int total;
    private int start;
    private int display;
    private List<ItemsBean> items;

    public String getLastBuildDate() {
        return lastBuildDate;
    }

    public void setLastBuildDate(String lastBuildDate) {
        this.lastBuildDate = lastBuildDate;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getDisplay() {
        return display;
    }

    public void setDisplay(int display) {
        this.display = display;
    }

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public static class ItemsBean {
        /**
         * title : 달려라! T<b>학교</b> 농구부
         * link : https://movie.naver.com/movie/bi/mi/basic.nhn?code=172102
         * image :
         * subtitle : 走れ！T校バスケット部
         * pubDate : 2018
         * director : 후루사와 켄|
         * actor : 시손 쥰|사노 하야토|하야미 아카리|토즈카 준키|
         * userRating : 0.00
         */

        private String title;
        private String link;
        private String image;
        private String subtitle;
        private String pubDate;
        private String director;
        private String actor;
        private String userRating;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getLink() {
            return link;
        }

        public void setLink(String link) {
            this.link = link;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getSubtitle() {
            return subtitle;
        }

        public void setSubtitle(String subtitle) {
            this.subtitle = subtitle;
        }

        public String getPubDate() {
            return pubDate;
        }

        public void setPubDate(String pubDate) {
            this.pubDate = pubDate;
        }

        public String getDirector() {
            return director;
        }

        public void setDirector(String director) {
            this.director = director;
        }

        public String getActor() {
            return actor;
        }

        public void setActor(String actor) {
            this.actor = actor;
        }

        public String getUserRating() {
            return userRating;
        }

        public void setUserRating(String userRating) {
            this.userRating = userRating;
        }
    }
}
