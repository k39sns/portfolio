package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class JdbcUtil {
	public static Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url 
			= "jdbc:mysql://gondr.asuscomm.com/yy_30204?" 
			+ "useUnicode=true&characterEncoding=utf8"
			+ "&useSSL=false&serverTimezone=Asia/Seoul";
			
			String user = "yy_30204";
			String pass = "1234";
			
			conn = DriverManager.getConnection(url, user, pass);
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	public static void close(Connection value) {
		if(value != null) {
			try { value.close(); } catch (Exception e) {}
		}
	}
	
	public static void close(PreparedStatement value) {
		if(value != null) {
			try { value.close(); } catch (Exception e) {}
		}
	}
	
	public static void close(ResultSet value) {
		if(value != null) {
			try { value.close(); } catch (Exception e) {}
		}
	}
}