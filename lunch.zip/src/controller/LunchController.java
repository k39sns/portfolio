package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import jdbc.JdbcUtil;
import vo.ResponseVO;

@WebServlet("/lunch")
public class LunchController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher(
				"/WEB-INF/views/index.jsp");
		rd.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String date = req.getParameter("date");
		resp.setContentType("application/json; charset=utf-8");
		
		PrintWriter out = resp.getWriter();
		Gson gson = new GsonBuilder().create();
		
		if(date == null || date.equals("")) {
			out.print(
				gson.toJson(
					new ResponseVO(false, "올바르지 않은 날짜입니다")
				)
			);
		}
		
		Connection con = JdbcUtil.getConnection();
		if(con == null) {
			out.print(
				gson.toJson(
					new ResponseVO(false, "DB연결에 오류 발생, 잠시후 시도해주세요")
				)
			);
		}
		
		//���⿡ ���� �޽� �������� �κ�
		String menu = getMenuData(con, date);
		
		if(menu != null && !menu.equals("")) {
			out.print(
				gson.toJson(
					new ResponseVO(true, "성공적으로 불러왔습니다", menu)
				)
			);
		}else {
			out.print(
				gson.toJson(
					new ResponseVO(false, "불러오는 중 오류 발생")
				)
			)
			;
		}		
	}

	private String getMenuData(Connection con, String date) {
		//��ó���� DB�� �Է��� date�� ���� �ִ��� �Ǵ���
		//������ �װ� ����
		//������ �Ľ��ؼ� ����
		
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		
		try {
			String sql ="SELECT * FROM menus WHERE date = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, date);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getString("menu");
				
			}
			
			//��������� DB�� ������� �����ϴ°�
			Document doc = Jsoup.connect("http://www.y-y.hs.kr/lunch.view?date=" + date).get();
			Element menuDom = doc.selectFirst("#morning .menuName > span");
			
			if(menuDom != null) {				
				pstmt2 = con.prepareStatement("INSERT INTO menus(date, menu) VALUES ( ?, ?)");
				pstmt2.setString(1, date);
				pstmt2.setString(2, menuDom.text());
				pstmt2.executeUpdate();
				
				return menuDom.text();
			}

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(pstmt2);
			JdbcUtil.close(con);
		}
		
		return null;
	}
	
	
}